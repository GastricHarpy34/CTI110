# Prime Numbers
# 9/26/2018
# CTI-110 P5HW1 - Prime Numbers
# Denis Leahy
#
def isPrime( number ):
    evenDivision = 0
    if number <= 1:
        return Fasle
    for currentNumber in range( 1, number + 1 ):
        if number % currentNumber == 0:
            evenDivision = evenDivision + 1
            if evenDivision > 2:
                return False
    return True

def main():
    number = int( input( "Please enter a number: " ))
    print()
    if isPrime( number ):
        print( number, "is a prime number" )
    else:
        print( number, "is NOT a prime number" )

main()
