print('This is a test of IDLE')
