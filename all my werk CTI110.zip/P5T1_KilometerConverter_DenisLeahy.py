# Kilometer converter
# 9/26/2018
# CTI-110 P5T1_KilometerConverter 
# Denis Leahy
#
conversionfac = 0.6214
def main():
   kilometers = float (input("Enter a distance in kilometers: "))
   show_miles(kilometers)
def show_miles(km):
    miles = km * conversionfac
    print(km, "kilometers equals", miles, "miles.")
main()
