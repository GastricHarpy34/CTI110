Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:06:47) [MSC v.1914 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
============= RESTART: C:\Users\annan\Desktop\P3LAB_leahy_1_.py =============
Enter grade: 60
Traceback (most recent call last):
  File "C:\Users\annan\Desktop\P3LAB_leahy_1_.py", line 18, in <module>
    if score >= A_score:
NameError: name 'A_score' is not defined
>>> 
============= RESTART: C:\Users\annan\Desktop\P3LAB_leahy_1_.py =============
Enter grade: 90
Traceback (most recent call last):
  File "C:\Users\annan\Desktop\P3LAB_leahy_1_.py", line 18, in <module>
    if score >= A_score:
NameError: name 'A_score' is not defined
>>> 
============= RESTART: C:\Users\annan\Desktop\P3LAB_leahy_1_.py =============
Enter grade: 
