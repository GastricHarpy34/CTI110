# Feet to inches converter
# 9/26/2018
# CTI-110 P5T2_FeetToInches 
# Denis Leahy
#
in_per_foot = 12
def main():
    feet = int(input("Enter a number of feet: "))
    print(feet, "equals", ft_to_in(feet), "inches.")
def ft_to_in(feet):
    return feet * in_per_foot
main()
