# CTI-110
# P3HW1 - Roman Numerals 
# Denis Leahy
# 9/14/2018

userNumber = int( input( "Please enter a number between 1 and 10: "))

print()

if userNumber == 1:
    print( "I" )
elif userNumber == 2:
    print( "II" )
elif userNumber == 3:
    print( "III" )
elif userNumber == 4:
    print( "IV" )
elif userNumber == 5:
    print( "V" )
elif userNumber == 6:
    print( "VI" )
elif userNumber == 7:
    print( "VII" )
elif userNumber == 8:
    print( "VIII" )
elif userNumber == 9:
    print( "VIIII" )
elif userNumber == 10:
    print( "X" )
else:
    print( "Syntax Error: I said enter a number between 1 AND 10, RUN IT AGAIN" )

