# CTI-110 
# P3HW2 - Shipping Charges 
# Denis Leahy
# 9/14/2018

userWeightOfPackage = int( input( "Please enter the weight of the package: "))

if userWeightOfPackage <= 2:
    shippingCharges = 1.50
elif userWeightOfPackage < 7:
    shippingCharges = 3.00
elif userWeightOfPackage < 11:
    shippingCharges = 4.00
else:
    shippingCharges = 4.75

print( "\nFor a package weighing " + str( userWeightOfPackage ) + \
       " pounds, you will pay $" + format( shippingCharges, ",.2f" ) + " per pound." )
