temp = float(input('Please enter temperature: '))
temp2 = 9/5 * temp + 32
print('The temperature in Fahrenheit is', format(temp2))
