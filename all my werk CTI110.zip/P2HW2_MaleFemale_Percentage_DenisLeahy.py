# Create a Male to Female percentage calculator
# 9/9/2018
# CTI-110 P2HW2 - Male Female Percentage
# Denis Leahy

#///Method 1\\\

males = int( input( "Please enter the number of males in the class: "))
females = int( input( "Please enter the number of females in the class: "))
totalStudents = males + females

malePercentage = ( males / totalStudents ) * 100
femalePercentage = ( females / totalStudents ) * 100

print( "Male percentage: " + str( malePercentage ) + "%" )
print( "Female percentage: " + str( femalePercentage ) + "%" )

malePercentage = males / totalStudents
femalePercentage = females / totalStudents

#///Method 2\\\

print( "There are " + str( totalStudents ) + " students in the class. " + \
       format( malePercentage, ".0%" ) + " of them are males and " + \
       format( femalePercentage, ".0%" ) + " of them are females" )
