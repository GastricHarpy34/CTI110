# Celsius To Fahrenheit Temperature Converter
# 9/24/2018
# CTI-110 P4HW2 - Celsius to Fahrenheit Table
# Denis Leahy
#
while True:
 celsiusTemp = float( input( "Please enter a temperature in celcius: " ) )
 
 fahrenTemp = ( ( 9 / 5 ) * celsiusTemp ) + 32
 
 print( str( celsiusTemp ) + " degrees in Fahrenheit is " + \
       format( fahrenTemp , ".1f" ) )
