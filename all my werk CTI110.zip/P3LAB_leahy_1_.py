# Grade Converter
# Leahy
while True:
    def main():
        # This program takes a number grade and outputs a letter grade.
        # system uses 10-point grading scale
        # Define the rest of the scores

     score = int(input('Enter score: '))

     if score >= 90:
       grade = "A"
    
     elif score >= 80:
         grade = "B"
     
     elif score >= 70:
         grade = "C"
      
     elif score >= 60:
         grade = "D"
        
     elif score >= 50:
         grade = "F"
    
     elif score < 50:
         grade = "F"
        
     print("Your grade is " + format( grade ))
 
    # program start
    main()
    if input("Do you want to repeat? (y/n)") == "n":
        break
