# Play rock,paper,scissors!
# 9/27/2018
# CTI-110 P5HW2 - Rock, Paper, Scissors Game
# Denis Leahy
#

import random

def generateRandomNumber():
    randomNumber = random.randint( 1,3 )
    return randomNumber

def getComputerChoice( randomNumber ):
    if randomNumber == 1:
        computerChoice = "rock"
    elif randomNumber == 2:
        computerChoice = "paper"
    elif randomNumber == 3:
        computerChoice = "scissors"

    return computerChoice

def getUserChoice():
    userChoice = input( "Please enter your choice: " )
    return userChoice

def determineWinner( computerChoice, userChoice ):
    rockMessage = "The rock smashes the scissors"
    scissorMessage = "Scissors cuts paper"
    paperMessage = "Paper wraps rock"
    sameMessage = "You both chose the same answer, try again."
    
    if computerChoice == "rock":
        if userChoice == "scissors":
            winner = "Computer"
            message = rockMessage
        elif userChoice == "paper":
            winner = "You"
            message = paperMessage
        elif userChoice == "rock":
            winner = ""
            message = sameMessage
    elif computerChoice == "paper":
        if userChoice == "rock":
            winner = "Computer"
            message = rockMessage
        elif userChoice == "scissors":
            winner = "You"
            message = paperMessage
        elif userChoice == "paper":
            winner = ""
            message = sameMessage
    elif computerChoice == "scissors":
        if userChoice == "paper":
            winner = "Computer"
            message = rockMessage
        elif userChoice == "rock":
            winner = "You"
            message = paperMessage
        elif userChoice == "scissors":
            winner = ""
            message = sameMessage
        
def main():
    randomNumber = generateRandomNumber()
    computerChoice = getComputerChoice( randomNumber )
    userChoice = getUserChoice()
    print( "The computer chose", computerChoice, "the winner is ", winner)
main()
