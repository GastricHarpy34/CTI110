# Budget Analysis
# 9/25/2018
# CTI-110 P4HW1 - Budget Analysis
# Denis Leahy
#
while True:
    userBudget = float( input( "Please enter how you have budgeted for the month: ") )

    moreExpenses = "y"
    userTotalExpenses = 0

    while moreExpenses == "y":
        userTotalExpense = float( input( "Enter an expense: " ) )
        userTotalExpenses += userTotalExpense
        moreExpenses = input( "Do you have more expenses? Type y for yes, any key for no: " )

    print()
    if userTotalExpenses > userBudget:
        print( "You were over your budget of","$" + format( userBudget, ",.2f" ), \
               "by","$" + format( userTotalExpenses - userBudget, ",.2f") )
    elif userBudget > userTotalExpenses:
        print( "You were under your budget of","$" + format( userBudget, ",.2f" ), \
               "by","$" + format( userTotalExpenses - userBudget, ",.2f") )
    else:
        print( "You used exactly your budget of", \
               "$" + format( userBudget , ",.2f"),"." )
    

